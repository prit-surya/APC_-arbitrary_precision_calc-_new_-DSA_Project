/*****************
Name : Pritesh suryawanshi
Date :
Description :
Sample input :
Sample output :
******************/
#include <stdio.h>
#include <stdlib.h>   // For malloc, free, NULL
#include <string.h>   // For strlen
#include "bignum.h"

// Create a new node with the given data
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;
    newNode->prev = NULL;
    return newNode;
}

// Insert a node at the tail of the linked list
void insertAtTail(BigNum* num, int data) {
    Node* newNode = createNode(data);
    if (num->tail == NULL) {
        // If list is empty
        num->head = num->tail = newNode;
    } else {
        // Append to the end of the list
        num->tail->next = newNode;
        newNode->prev = num->tail;
        num->tail = newNode;
    }
    num->size++;
}

// Convert a string to BigNum by slicing into chunks of 9 digits
BigNum* stringToBigNum(const char* str) {
    BigNum* num = (BigNum*)malloc(sizeof(BigNum));
    num->head = num->tail = NULL;
    num->size = 0;

    int len = strlen(str);
    for (int i = len; i > 0; i -= 9) {
        int start = i - 9 < 0 ? 0 : i - 9;
        char buffer[10] = {0};
        strncpy(buffer, str + start, i - start);
        insertAtTail(num, atoi(buffer));
    }

    return num;
}

// Print the BigNum
void printBigNum(BigNum* num) {
    Node* current = num->head;
    if (current == NULL) {
        printf("0");
        return;
    }

    // Print the first node without leading zeros
    printf("%d", current->data);
    current = current->next;

    // Print remaining nodes with leading zeros (9 digits)
    while (current != NULL) {
        printf("%09d", current->data);
        current = current->next;
    }
    printf("\n");
}

// Function to compare two BigNums
int compareBigNum(BigNum* num1, BigNum* num2) {
    // Compare based on number of nodes (size)
    if (num1->size > num2->size) return 1;
    if (num1->size < num2->size) return -1;

    // If sizes are the same, compare node by node from the head
    Node* n1 = num1->head;
    Node* n2 = num2->head;

    while (n1 != NULL && n2 != NULL) {
        if (n1->data > n2->data) return 1;
        if (n1->data < n2->data) return -1;
        n1 = n1->next;
        n2 = n2->next;
    }

    return 0;  // They are equal
}

// Free memory used by the BigNum
void freeBigNum(BigNum* num) {
    Node* current = num->head;
    while (current != NULL) {
        Node* temp = current;
        current = current->next;
        free(temp);
    }
    free(num);
}

