/*****************
Name : Pritesh suryawanshi
Date : 15/9/2024
Description : Arbitrary Precision Calculator Project
Sample input : ./main
Sample output :
******************/
#include <stdio.h>
#include <stdlib.h>
#include "bignum.h"
#include "arithmetic.h"  // Include this to declare arithmetic functions

int main() {
    char num1_str[1000], num2_str[1000];
    int choice;

    printf("Enter first large number: ");
    scanf("%s", num1_str);
    printf("Enter second large number: ");
    scanf("%s", num2_str);

    BigNum* num1 = stringToBigNum(num1_str);
    BigNum* num2 = stringToBigNum(num2_str);

    printf("\nChoose operation:\n");
    printf("1. Addition\n");
    printf("2. Subtraction\n");
    printf("3. Multiplication\n");
    printf("4. Division\n");
    printf("Enter choice: ");
    scanf("%d", &choice);

    BigNum* result = NULL;

    switch (choice) {
        case 1:
            result = addBigNum(num1, num2);
            printf("Sum: ");
            break;
        case 2:
            result = subtractBigNum(num1, num2);
            printf("Difference: ");
            break;
        case 3:
            result = multiplyBigNum(num1, num2);
            printf("Product: ");
            break;
        case 4:
            result = divideBigNum(num1, num2);
            printf("Quotient: ");
            break;
        default:
            printf("Invalid choice!\n");
            return 1;
    }

    printBigNum(result);

    return 0;
}

