#ifndef ARITHMETIC_H
#define ARITHMETIC_H

#include "bignum.h"

// Function declarations for arithmetic operations
BigNum* addBigNum(BigNum* num1, BigNum* num2);
BigNum* subtractBigNum(BigNum* num1, BigNum* num2);
BigNum* multiplyBigNum(BigNum* num1, BigNum* num2);
BigNum* divideBigNum(BigNum* num1, BigNum* num2);

#endif

