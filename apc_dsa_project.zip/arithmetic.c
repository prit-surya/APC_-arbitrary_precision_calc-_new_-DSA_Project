/*****************
Name : Pritesh suryawanshi
Date :
Description :
Sample input :
Sample output :
******************/
#include <stdio.h>
#include <stdlib.h>  // This includes malloc, free, and NULL
#include "bignum.h"
#include "arithmetic.h"


// Function to add two BigNums
BigNum* addBigNum(BigNum* num1, BigNum* num2) {
    BigNum* result = (BigNum*)malloc(sizeof(BigNum));
    result->head = result->tail = NULL;
    result->size = 0;

    Node* n1 = num1->tail;
    Node* n2 = num2->tail;
    int carry = 0;

    while (n1 != NULL || n2 != NULL || carry != 0) {
        int sum = carry;
        if (n1 != NULL) {
            sum += n1->data;
            n1 = n1->prev;
        }
        if (n2 != NULL) {
            sum += n2->data;
            n2 = n2->prev;
        }
        carry = sum / 1000000000;
        insertAtTail(result, sum % 1000000000);
    }

    return result;
}
BigNum* subtractBigNum(BigNum* num1, BigNum* num2) {
    BigNum* result = (BigNum*)malloc(sizeof(BigNum));
    result->head = result->tail = NULL;
    result->size = 0;

    Node* n1 = num1->tail;
    Node* n2 = num2->tail;
    int borrow = 0;

    while (n1 != NULL) {
        int diff = n1->data - (n2 ? n2->data : 0) - borrow;
        if (diff < 0) {
            diff += 1000000000;
            borrow = 1;
        } else {
            borrow = 0;
        }

        insertAtTail(result, diff);

        n1 = n1->prev;
        if (n2 != NULL) n2 = n2->prev;
    }

    // Remove leading zeros from the result
    while (result->tail && result->tail->data == 0) {
        Node* toDelete = result->tail;
        result->tail = result->tail->prev;
        if (result->tail) result->tail->next = NULL;
        free(toDelete);
    }

    return result;
}
BigNum* multiplyBigNum(BigNum* num1, BigNum* num2) {
    BigNum* result = (BigNum*)malloc(sizeof(BigNum));
    result->head = result->tail = NULL;
    result->size = 0;

    Node* n2 = num2->tail;
    int shift = 0;

    // Loop through each node in num2 and multiply it with num1
    while (n2 != NULL) {
        BigNum* tempResult = (BigNum*)malloc(sizeof(BigNum));
        tempResult->head = tempResult->tail = NULL;
        tempResult->size = 0;

        Node* n1 = num1->tail;
        int carry = 0;

        // Multiply each block of num1 with the current block of num2
        while (n1 != NULL) {
            long long product = (long long)n1->data * n2->data + carry;
            carry = product / 1000000000;
            insertAtTail(tempResult, product % 1000000000);
            n1 = n1->prev;
        }
        if (carry > 0) insertAtTail(tempResult, carry);

        // Add zeros to the temp result (shift)
        for (int i = 0; i < shift; i++) {
            insertAtTail(tempResult, 0);
        }

        // Add tempResult to final result
        result = addBigNum(result, tempResult);

        n2 = n2->prev;
        shift++;
    }

    return result;
}
BigNum* divideBigNum(BigNum* num1, BigNum* num2) {
    BigNum* quotient = (BigNum*)malloc(sizeof(BigNum));
    quotient->head = quotient->tail = NULL;
    quotient->size = 0;

    BigNum* remainder = (BigNum*)malloc(sizeof(BigNum));
    remainder->head = remainder->tail = NULL;
    remainder->size = 0;

    Node* n1 = num1->head;
    while (n1 != NULL) {
        insertAtTail(remainder, n1->data);
        n1 = n1->next;

        int count = 0;
        while (compareBigNum(remainder, num2) >= 0) {
            remainder = subtractBigNum(remainder, num2);
            count++;
        }

        insertAtTail(quotient, count);
    }

    return quotient;
}

