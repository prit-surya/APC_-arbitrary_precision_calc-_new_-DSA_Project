#ifndef BIGNUM_H
#define BIGNUM_H

// Define the Node structure
typedef struct Node {
    int data;
    struct Node* next;
    struct Node* prev;
} Node;

// Define the BigNum structure
typedef struct {
    Node* head;
    Node* tail;
    int size;   // Number of blocks (each block is 9 digits)
} BigNum;

// Function prototypes
Node* createNode(int data);
void insertAtTail(BigNum* num, int data);
BigNum* stringToBigNum(const char* str);  // Updated to use 'const char*'
void printBigNum(BigNum* num);
int compareBigNum(BigNum* num1, BigNum* num2);
void freeBigNum(BigNum* num);

#endif

